document.addEventListener('DOMContentLoaded', function() {
    const codeInput = document.getElementById('codeInput');
    const languageSelect = document.getElementById('language');
    const optimizeBtn = document.getElementById('optimizeBtn');
    const clearBtn = document.getElementById('clearBtn');
    const sampleBtn = document.getElementById('sampleBtn');
    const copyBtn = document.getElementById('copyBtn');
    const resultDiv = document.getElementById('result');
    
    // Sample code snippets for different languages
    const samples = {
        python: `def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n-1)`,
        
        javascript: `function findMax(arr) {
    let max = arr[0];
    for (let i = 1; i < arr.length; i++) {
        if (arr[i] > max) {
            max = arr[i];
        }
    }
    return max;
}`,
        
        c: `#include <stdio.h>
        
int fibonacci(int n) {
    if (n <= 1)
        return n;
    return fibonacci(n-1) + fibonacci(n-2);
}`,
        
        cpp: `#include <iostream>
#include <vector>
        
using namespace std;
        
double calculateAverage(const vector<int>& numbers) {
    int sum = 0;
    for (int num : numbers) {
        sum += num;
    }
    return static_cast<double>(sum) / numbers.size();
}`,
        
        csharp: `using System;
        
public class StringHelper {
    public static string ReverseString(string input) {
        char[] charArray = input.ToCharArray();
        Array.Reverse(charArray);
        return new string(charArray);
    }
}`,
        
        go: `package main
        
import "fmt"
        
func isPrime(n int) bool {
    if n <= 1 {
        return false
    }
    for i := 2; i*i <= n; i++ {
        if n%i == 0 {
            return false
        }
    }
    return true
}`,
        
        rust: `fn count_vowels(s: &str) -> usize {
    s.chars().filter(|c| match c {
        'a' | 'e' | 'i' | 'o' | 'u' => true,
        _ => false,
    }).count()
}`
    };
    
    // Set sample code when language changes
    languageSelect.addEventListener('change', function() {
        const lang = this.value;
        if (samples[lang] && !codeInput.value.trim()) {
            codeInput.value = samples[lang];
        }
    });
    
    // Clear button
    clearBtn.addEventListener('click', function(e) {
        e.preventDefault();
        codeInput.value = '';
        resultDiv.innerHTML = `
            <div class="placeholder">
                <i class="fas fa-robot"></i>
                <p>Your optimized code will appear here</p>
            </div>
        `;
    });
    
    // Sample button
    sampleBtn.addEventListener('click', function(e) {
        e.preventDefault();
        const lang = languageSelect.value;
        codeInput.value = samples[lang] || samples['python'];
    });
    
    // Copy button
    copyBtn.addEventListener('click', function(e) {
        e.preventDefault();
        const resultText = resultDiv.textContent;
        if (resultText && !resultDiv.querySelector('.placeholder')) {
            navigator.clipboard.writeText(resultText)
                .then(() => {
                    const originalText = copyBtn.innerHTML;
                    copyBtn.innerHTML = '<i class="fas fa-check"></i> Copied!';
                    setTimeout(() => {
                        copyBtn.innerHTML = originalText;
                    }, 2000);
                });
        }
    });
    
    // Optimize button
    optimizeBtn.addEventListener('click', async function(e) {
        e.preventDefault();
        const code = codeInput.value.trim();
        const language = languageSelect.value;
        
        if (!code) {
            resultDiv.innerHTML = `
                <div class="placeholder">
                    <i class="fas fa-exclamation-circle"></i>
                    <p>Please enter some code to optimize</p>
                </div>
            `;
            return;
        }
        
        // Show loading state
        optimizeBtn.disabled = true;
        optimizeBtn.innerHTML = '<span class="loading"></span> Optimizing...';
        
        resultDiv.innerHTML = `
            <div style="text-align: center; padding: 2rem;">
                <span class="loading" style="width: 40px; height: 40px; border-width: 4px;"></span>
                <p style="margin-top: 1rem;">Analyzing your ${language} code...</p>
            </div>
        `;
        
        try {
            const response = await fetch('/optimize', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ code, language }),
            });
            
            const data = await response.json();
            
            if (data.error) {
                resultDiv.innerHTML = `
                    <div class="placeholder">
                        <i class="fas fa-exclamation-triangle"></i>
                        <p>Error: ${data.error}</p>
                    </div>
                `;
            } else {
                resultDiv.innerHTML = `<pre>${data.optimized_code}</pre>`;
            }
        } catch (error) {
            resultDiv.innerHTML = `
                <div class="placeholder">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>Error: Could not connect to the server</p>
                </div>
            `;
        } finally {
            optimizeBtn.disabled = false;
            optimizeBtn.innerHTML = '<i class="fas fa-magic"></i> Optimize Code';
        }
    });
});