from flask import Flask, request, jsonify, render_template
import openai
import os
from dotenv import load_dotenv
from time import sleep

# Load environment variables
load_dotenv()

app = Flask(__name__)

# Configuration
app.config['SECRET_KEY'] = os.getenv('FLASK_SECRET_KEY', 'dev-secret')
openai.api_key = os.getenv("OPENAI_API_KEY")

# Language-specific optimization prompts
LANGUAGE_PROMPTS = {
    "python": {
        "system": "You are an expert Python developer specializing in code optimization.",
        "prompt": "Optimize this Python code focusing on:\n1. Performance (time/space complexity)\n2. PEP 8 style guidelines\n3. Pythonic idioms\n4. Error handling\n\nProvide the optimized code with brief inline comments explaining changes."
    },
    "javascript": {
        "system": "You are a senior JavaScript engineer optimizing code for modern browsers and Node.js.",
        "prompt": "Improve this JavaScript code considering:\n1. ES6+ features\n2. Performance best practices\n3. Readability\n4. Error handling\n\nInclude concise comments explaining optimizations."
    },
    "c": {
        "system": "You are a C programming expert focusing on low-level optimizations.",
        "prompt": "Optimize this C code for:\n1. Memory efficiency\n2. Execution speed\n3. Portability\n4. Safety (buffer overflows, etc.)\n\nAdd comments explaining each optimization."
    },
    "cpp": {
        "system": "You are a C++ expert specializing in modern C++ (C++11/14/17/20) optimizations.",
        "prompt": "Improve this C++ code using:\n1. Modern C++ features\n2. STL best practices\n3. Memory management\n4. Performance optimizations\n\nComment on key improvements."
    },
    "csharp": {
        "system": "You are a C# architect with deep knowledge of .NET optimizations.",
        "prompt": "Optimize this C# code focusing on:\n1. .NET best practices\n2. LINQ efficiency\n3. Memory management\n4. Asynchronous patterns\n\nAdd explanatory comments."
    },
    "java": {
        "system": "You are a Java performance tuning specialist.",
        "prompt": "Improve this Java code considering:\n1. JVM optimizations\n2. Collections usage\n3. Memory efficiency\n4. Modern Java features\n\nInclude optimization comments."
    },
    "go": {
        "system": "You are a Go (Golang) expert focusing on idiomatic and efficient code.",
        "prompt": "Optimize this Go code for:\n1. Goroutine efficiency\n2. Memory allocation\n3. Standard library best practices\n4. Error handling\n\nAdd brief optimization notes."
    },
    "rust": {
        "system": "You are a Rust expert specializing in zero-cost abstractions.",
        "prompt": "Improve this Rust code focusing on:\n1. Ownership patterns\n2. Performance\n3. Memory safety\n4. Idiomatic Rust\n\nComment on key optimizations."
    }
}

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/optimize", methods=["POST"])
def optimize_code():
    try:
        data = request.get_json()
        code = data.get("code", "").strip()
        language = data.get("language", "python")
        
        if not code:
            return jsonify({"error": "Please provide code to optimize"}), 400
        
        # Get language-specific prompt
        lang_config = LANGUAGE_PROMPTS.get(language, LANGUAGE_PROMPTS["python"])
        
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": lang_config["system"]},
                {"role": "user", "content": f"{lang_config['prompt']}\n\nOriginal Code:\n{code}\n\nOptimized Code:"}
            ],
            temperature=0.7,
            max_tokens=1000
        )

        optimized_code = response.choices[0].message["content"]
        return jsonify({"optimized_code": optimized_code})

    except openai.error.RateLimitError:
        return jsonify({"error": "API rate limit exceeded. Please try again later."}), 429
    except openai.error.AuthenticationError:
        return jsonify({"error": "Invalid API key. Please check your configuration."}), 401
    except Exception as e:
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500

if __name__ == "__main__":
    app.run(debug=True)